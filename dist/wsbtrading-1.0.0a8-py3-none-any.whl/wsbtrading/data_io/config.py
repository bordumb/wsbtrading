# authentication and connection details
BASE_URL = 'X'
API_KEY = 'X'
SECRET_KEY = 'X'
