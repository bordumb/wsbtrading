import config
import websocket as ws
import requests
import json

import alpaca_trade_api as tradeapi
import requests

from wsbtrading.instrumentation import Alpaca as iAlpaca

#
# api = tradeapi.REST(base_url=iAlpaca.api_call['data_stream']['base_url'],
#                     key_id=iAlpaca.api_key,
#                     secret_key=iAlpaca.secret_key)
#
# session = requests.session()
#
#
# {"action": "authenticate","data": {"key_id": "PK847B96RX8C9GJ3AMO7","secret_key": "3ZdZzKEXYwJQxQtq7JNK0KDeatZXzvQSvAwZPuqh"}}
# < {"stream":"authorization","data":{"action":"authenticate","status":"authorized"}}
#
# {"action": "listen","data": {"streams": ["T.SPY"]}}
#
#

def alpaca_authenticate(ws):
    auth_data = {
        "action": "authenticate",
        "data": {"key_id": iAlpaca.api_key, "secret_key": iAlpaca.secret_key}
    }
    ws.send(data=json.dumps(auth_data))


def on_open(ws):
    print("opened")
    auth_data = {
        "action": "authenticate",
        "data": {"key_id": config.API_KEY, "secret_key": config.SECRET_KEY}
    }

    ws.send(json.dumps(auth_data))

    listen_message = {"action": "listen", "data": {"streams": ["AM.TSLA"]}}

    ws.send(json.dumps(listen_message))


def on_message(ws, message):
    print("received a message")
    print(message)


def on_close(ws):
    print("closed connection")


socket = "wss://data.alpaca.markets/stream"


ws = websocket.WebSocketApp(socket, on_open=on_open, on_message=on_message, on_close=on_close)
ws.run_forever()
